package bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorldController {
	
@RequestMapping("abc")
public String displayHello()
{
	return "hello";
}
}
